###########################
#       Clase 2
#    Econometría 1
#    Complementaria
#      2022-01


# Intro -------------------------------------------------------------------
#  Interfaz: R tiene múltiples paneles para facilitar su uso.
#  ¿Atajos? Alt+Shift+K para abrir la lista de atajos de R
#     ##Algunos atajos útiles
#     ## Ctrl+L : para limpiar la consola
#     ## Alt+-  : inserta el signo de asignación "<-"
#     ## Ctrl+Shift+C : para comentar o "des-comentar" una línea de código
#     ## Ctrl+Enter: Para correr las líneas seleccionadas
#  R tiene muchos Cheat Sheets que pueden ser útiles. En la pestaña "Help"
#  encuentran algunas de las más usadas. 
# Las cosas en R cambian un poco de lo que veníamos trabajando con Stata
# Al ser un lenguaje de programación, vamos a hablar de funciones y no de comandos


# Funciones para identificación y conversión de objetos -------------------

# función repetir, no estoy especificando argumentos 
# Intrucción: repite el número 2, 5 veces en un vector
rep(2,5)

#función c
# combinar escalares en un vector
c(1,2,4,7)

#función rep
# podemos o no especificar el x, la instrucción asigna 5 veces el 1 en un vector
rep(x=1,5)

#función secuencia

seq(from = 1,to = 10, by = 2)
#Crea una secuencia que empezara en 1 y aumentara en 2 (que no pasara de 10)

seq(1, 10, length.out = 5)
# secuencia de 5 números, con aumentos elegidos por r

1:3
# corre números desde 1 a 3

rep(x = 1:3,each=2)
# correr números del 1 al 3, repitiendo cada uno dos veces
#  ________________________________________________________
          # AYUDA
          #¿Qué más puede hacer la función de repetir?
          ?rep
          help("rep")
          # Ctrl+3 para abrir el panel de ayuda.
          # ¿Dónde más pedir ayuda?
          #  Foros como Stack Overflow y R Blogger
          #  Horarios de atención de los complementarios.
#  ________________________________________________________

# función type of me permite conocer el tipo del argumento
typeof(x="a")  
typeof(x=1L) #para definir un integer debo poner una L mayúscula después
typeof(x=1.5)
typeof(3+1i)
typeof(TRUE)

#Otras forma de conocer el tipo
class(x="a")
is.numeric("a")
#¿Cómo cambio el tipo de dato?
# función as
# función para cambiar el tipo de dato
as.character(2)
as.numeric("2.1")

# Guardar estructuras de datos --------------------------------------------
par_20<-seq(2,20,2) #Veanlo en el panel de "Environment" Ctrl+8
par_20
# Para eliminarlos
rm("par_20")

# Condicionales -----------------------------------------------------------
#   *-------------------------------------------------------------------*
#   * 	Expresiones Lógicas 					  Significado				
#   *-------------------------------------------------------------------*
#   *			  &, |						            Y (And), O (Or)			
#   *			  >,<							          Mayor que, Menor que		
#   *		   ==, !=						        Igual a, Diferente a		
#   *		   >=, <=				        	Mayor Igual, Menor o Igual 	
#   *		   !    				        	            No es 	
#   *-------------------------------------------------------------------*
#   *	Expresiones Aritméticas 									
#   *-------------------------------------------------------------------*
#   *			+, -							            Más, Menos				
#   *			*, /					          Multiplicación, Division 		
#   *			%%					            Restante de una división		
#   *			%/%					              División de enteros		
#   *-------------------------------------------------------------------*
#IFELSE
#ifelse es lo mismo que un si en excel
ifelse("a"=="b", #Expresión lógica a evaluar
       1, #Resultado si la expresión es verdadera
       0) #Resultado si la expresión es falsa

ifelse(2>=1, "2 es mayor o igual a 1", "2 es menor a 1?")

# IF
if (2>4) {
  "2 es mayor a 4"
} else if (2>3) {
  "2 es mayor a 3"
} else {
  "2 no es mayor a 3 o a 4"
}

#Expresiones arítmeticas
2+2
4-3
5*2
16/6
16%%6
16%/%6


# Importar bases de datos -------------------------------------------------
setwd('C:/Users/Diana C Contreras/OneDrive - Universidad de Los Andes/202210_Econometría1/Clase_2')
# OJO: Cuando vayan a pegar la dirección asegurense que los 
#          slash sean "/" y no "\". R a veces no reconoce los segundos.

#Para ver en qué directorio estoy trabajando
getwd()


nbi_1993<-read.csv('NBI_1993.csv', header=TRUE, sep=",")
# ¿Cómo leer archivos de excel?
#  ________________________________________________________
      # En R al igual que en Stata no todos los paquetes están instalados
      #  Es necesario instalar. En este caso vamos a instalar un paquete para 
      #  importar los archivos de excel.
          install.packages('readxl')
      # Una vez instalado es necesario decirle a R que vamos a utilizar ese
      # Paquete en esta sesión:
          library("readxl")
#  ________________________________________________________

# Ahora si, utilicemos el paquete que instalamos:
nbi_2011<-read_excel("NBI_2011.xlsx", sheet = 'Municipios')
  
  # TAREA: La clase pasada en stata le indicamos al computador que
  # solo queriamos importar 1126 observaciones. Busquen en "help" el comando
  # read_excel y utilicen la información de los argumentos para hacer lo
  # mismo que en stata, importar solo 1000 observaciones.

#Para leer el archivo .dta
install.packages('readstata13')
library("readstata13")
Base_clase_1<-read.dta13("Base_clase_1.dta") 
# Inspeccionemos que hay en las 3 base de datos.
str(nbi_2011) 

head(nbi_1993)

View(Base_clase_1)


# Estadísticas descríptivas -----------------------------------------------

#Para ver los valores únicos de una variable
table(Base_clase_1$qq1)
table(Base_clase_1$qq1, useNA = 'ifany')
# Como sacar estadísticas descriptivas de las variables   
summary(nbi_1993$NBI)   
summary(Base_clase_1[,9:11])

# Como saber la proporción de missings en una variable
prop.table(nbi_1993$cod_dpto)
prop.table(table(is.na(nbi_1993$cod_dpto)))*100


# Crear nuevas variables --------------------------------------------------

#Para crear nuevas variables dentro de una base de datos
Base_clase_1$nueva_var <- Base_clase_1$pipps*100
Base_clase_1$edad_madre <- rnorm(nrow(Base_clase_1),30,15)
# Variables de caracterés
Base_clase_1$cod_mpio <- substr(Base_clase_1$depmuni, 3,5)
Base_clase_1$cod_depto <- substr(Base_clase_1$depmuni, 1,2)

# Visualizar datos --------------------------------------------------------

# Hagamos un histograma de la variable edad_madre
hist(Base_clase_1$edad_madre)

# Un paquete frecuentemente utilizado para la visualización de datos es ggplot2
# Este paquete funciona con capas.Les recomendamos revisar la documentación
# y preguntarnos si tienen alguna inquietud.
install.packages('ggplot2')
library('ggplot2')
ggplot(data = Base_clase_1, mapping = aes(x = as.factor(cod_depto), y = ingresos_hogar_jefe)) +
  geom_bar(stat = "identity") +
  labs(x = "Departamento", y="Ingresos del hogar")

# Para eliminar todos los objetos.
rm(list=ls())
